#!/usr/bin/env bash
# provision.sh — Standalone provisioner for libravdbd runtime assets.
#
# Downloads and verifies the ONNX runtime library and embedding
# models required by libravdbd.  Designed to run on macOS (arm64/amd64)
# and Linux (x64/arm64); Windows is not supported by this script.
#
# The script is idempotent: existing assets that pass SHA-256 verification
# are left in place.
#
# Usage:
#   bash scripts/provision.sh [--target DIR] [--help]
#
# Options:
#   --target DIR         Base directory for the .daemon-bin tree.
#                        Defaults to <script-dir>/../.daemon-bin
#   --help               Print this message and exit.
#
# The resulting directory layout:
#
#   <target>/
#     models/
#       nomic-embed-text-v1.5/
#         model.onnx
#         tokenizer.json
#         embedding.json
#       bge-small-en-v1.5/
#         model.onnx
#         tokenizer.json
#         embedding.json
#     onnxruntime/
#       onnxruntime-<platform>/
#         lib/
#           libonnxruntime.dylib  (macOS)
#           libonnxruntime.so     (Linux)

set -euo pipefail

# ── Helpers ───────────────────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { printf "${CYAN}[provision]${NC} %s\n" "$*"; }
ok()    { printf "${GREEN}[provision]${NC} %s\n" "$*"; }
warn()  { printf "${YELLOW}[provision]${NC} %s\n" "$*" >&2; }
die()   { printf "${RED}[provision]${NC} %s\n" "$*" >&2; exit 1; }

# ── Argument parsing ──────────────────────────────────────────────────

TARGET_DIR="${ROOT_DIR}/.daemon-bin"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target)
      [[ $# -ge 2 && "$2" != --* ]] || die "Missing argument for --target"
      TARGET_DIR="$2"; shift 2 ;;
    --help|-h)
      sed -n '2,/^$/{ s/^# //; s/^#//; p; }' "$0"
      exit 0 ;;
    *)
      die "Unknown option: $1.  Use --help for usage." ;;
  esac
done

MODELS_DIR="${TARGET_DIR}/models"
RUNTIME_DIR="${TARGET_DIR}/onnxruntime"

# ── Platform detection ────────────────────────────────────────────────

detect_platform() {
  local os arch
  os="$(uname -s)"
  arch="$(uname -m)"
  case "$os" in
    Darwin) os="darwin" ;;
    Linux)  os="linux" ;;
    *)      die "Unsupported OS: $os" ;;
  esac
  case "$arch" in
    arm64|aarch64) arch="arm64" ;;
    x86_64)        arch="amd64" ;;
    *)             die "Unsupported architecture: $arch" ;;
  esac
  echo "${os}-${arch}"
}

PLATFORM="$(detect_platform)"
info "Platform: ${PLATFORM}"

# ── SHA-256 verification ─────────────────────────────────────────────

verify_sha256() {
  local file="$1" expected="$2"
  [[ -f "$file" ]] || return 1
  [[ -z "$expected" ]] && return 0
  local actual
  if command -v shasum >/dev/null 2>&1; then
    actual="$(shasum -a 256 "$file" | awk '{print $1}')"
  elif command -v sha256sum >/dev/null 2>&1; then
    actual="$(sha256sum "$file" | awk '{print $1}')"
  else
    die "Neither shasum nor sha256sum found on PATH"
  fi
  [[ "$actual" == "$expected" ]]
}

# ── Download helper ───────────────────────────────────────────────────

download() {
  local url="$1" dest="$2"
  mkdir -p "$(dirname "$dest")"
  local tmp="${dest}.tmp.$$"
  if command -v curl >/dev/null 2>&1; then
    curl -fSL --retry 3 --progress-bar -o "$tmp" "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -q --show-progress -O "$tmp" "$url"
  else
    die "Neither curl nor wget found on PATH"
  fi
  mv -f "$tmp" "$dest"
}

# ── Asset provisioning ───────────────────────────────────────────────

ensure_asset() {
  local name="$1" url="$2" dest="$3" sha256="${4:-}" optional="${5:-}"
  if verify_sha256 "$dest" "$sha256"; then
    ok "  ✓ ${name} (cached)"
    return 0
  fi
  info "  ↓ Downloading ${name}…"
  download "$url" "$dest"
  if [[ -n "$sha256" ]] && ! verify_sha256 "$dest" "$sha256"; then
    rm -f "$dest"
    if [[ "$optional" == "optional" ]]; then
      warn "  SHA-256 verification failed for ${name} (skipping optional asset)"
      return 1
    fi
    die "SHA-256 verification failed for ${name}"
  fi
  ok "  ✓ ${name}"
}

# ── Model manifest writers ───────────────────────────────────────────

write_nomic_manifest() {
  local model_file="${1:-model.onnx}"
  local dir="${MODELS_DIR}/nomic-embed-text-v1.5"
  mkdir -p "$dir"
  cat > "${dir}/embedding.json" <<MANIFEST
{
  "backend": "onnx-local",
  "profile": "nomic-embed-text-v1.5",
  "family": "nomic-embed-text-v1.5",
  "model": "${model_file}",
  "tokenizer": "tokenizer.json",
  "dimensions": 768,
  "normalize": true,
  "device": "cpu",
  "inputNames": ["input_ids", "attention_mask", "token_type_ids"],
  "outputName": "last_hidden_state",
  "pooling": "mean",
  "addSpecialTokens": true
}
MANIFEST
}

write_bge_manifest() {
  local dir="${MODELS_DIR}/bge-small-en-v1.5"
  mkdir -p "$dir"
  cat > "${dir}/embedding.json" <<'MANIFEST'
{
  "backend": "onnx-local",
  "profile": "bge-small-en-v1.5",
  "family": "bge",
  "model": "model.onnx",
  "tokenizer": "tokenizer.json",
  "dimensions": 384,
  "normalize": true,
  "maxContextTokens": 512,
  "inputNames": ["input_ids", "attention_mask", "token_type_ids"],
  "outputName": "last_hidden_state",
  "pooling": "mean",
  "addSpecialTokens": true
}
MANIFEST
}

# ── ONNX Runtime ──────────────────────────────────────────────────────

ONNXRUNTIME_VERSION="1.25.1"

declare -A RUNTIME_ARCHIVE RUNTIME_URL RUNTIME_SHA256 RUNTIME_LIB

RUNTIME_ARCHIVE[darwin-arm64]="onnxruntime-osx-arm64-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_URL[darwin-arm64]="https://github.com/microsoft/onnxruntime/releases/download/v${ONNXRUNTIME_VERSION}/onnxruntime-osx-arm64-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_SHA256[darwin-arm64]="18987ec3187b5f29ba798109750f6135060560ad4e0a52678fcc753ee8fb3091"
RUNTIME_LIB[darwin-arm64]="onnxruntime-osx-arm64-${ONNXRUNTIME_VERSION}/lib/libonnxruntime.dylib"

# Intel Mac: Microsoft stopped shipping pre-built x86_64 macOS binaries after v1.23.0.
# We build from source and host at a permanent release tag in our own repo.
RUNTIME_ARCHIVE[darwin-amd64]="onnxruntime-osx-x86_64-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_URL[darwin-amd64]="https://github.com/xDarkicex/homebrew-openclaw-libravdb-memory/releases/download/ort-darwin-amd64-v${ONNXRUNTIME_VERSION}/onnxruntime-osx-x86_64-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_SHA256[darwin-amd64]="a6bbd18a17fbbd651cfa331e5361520684e7501da3b73f0a01c79c95433fa007"
RUNTIME_LIB[darwin-amd64]="onnxruntime-osx-x86_64-${ONNXRUNTIME_VERSION}/lib/libonnxruntime.dylib"

RUNTIME_ARCHIVE[linux-amd64]="onnxruntime-linux-x64-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_URL[linux-amd64]="https://github.com/microsoft/onnxruntime/releases/download/v${ONNXRUNTIME_VERSION}/onnxruntime-linux-x64-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_SHA256[linux-amd64]="eb566a49cfc49ef0642f809b69340b5bb656c7c4905ba873526d226f2c005816"
RUNTIME_LIB[linux-amd64]="onnxruntime-linux-x64-${ONNXRUNTIME_VERSION}/lib/libonnxruntime.so"

RUNTIME_ARCHIVE[linux-arm64]="onnxruntime-linux-aarch64-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_URL[linux-arm64]="https://github.com/microsoft/onnxruntime/releases/download/v${ONNXRUNTIME_VERSION}/onnxruntime-linux-aarch64-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_SHA256[linux-arm64]="daa71b56b00c4ab34798a3d96ca41a32ece4d3e302dc2386d3cca83fd4491214"
RUNTIME_LIB[linux-arm64]="onnxruntime-linux-aarch64-${ONNXRUNTIME_VERSION}/lib/libonnxruntime.so"

# GPU-accelerated ONNX Runtime variants (Linux amd64 only; Microsoft does not publish a GPU build for aarch64).
declare -A RUNTIME_GPU_ARCHIVE RUNTIME_GPU_URL RUNTIME_GPU_SHA256 RUNTIME_GPU_LIB

RUNTIME_GPU_ARCHIVE[linux-amd64]="onnxruntime-linux-x64-gpu-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_GPU_URL[linux-amd64]="https://github.com/microsoft/onnxruntime/releases/download/v${ONNXRUNTIME_VERSION}/onnxruntime-linux-x64-gpu-${ONNXRUNTIME_VERSION}.tgz"
RUNTIME_GPU_SHA256[linux-amd64]="ddfc4ca4ccc9cd5345d3820edab710ee84e749569d052eed92c42693d3b448a8"
RUNTIME_GPU_LIB[linux-amd64]="onnxruntime-linux-x64-gpu-${ONNXRUNTIME_VERSION}/lib/libonnxruntime.so"

provision_one_runtime() {
  local label="$1" archive_name="$2" url="$3" sha256="$4" lib_rel="$5"

  local lib_path="${RUNTIME_DIR}/${lib_rel}"
  if [[ -f "$lib_path" ]]; then
    ok "ONNX runtime (${label}) already present"
    return 0
  fi

  info "Provisioning ONNX runtime (${label}) for ${PLATFORM}…"
  mkdir -p "$RUNTIME_DIR"
  local archive_path="${RUNTIME_DIR}/${archive_name}"

  if ! verify_sha256 "$archive_path" "$sha256"; then
    download "$url" "$archive_path"
    if [[ -n "$sha256" ]] && ! verify_sha256 "$archive_path" "$sha256"; then
      rm -f "$archive_path"
      die "SHA-256 verification failed for ONNX runtime (${label}) archive"
    fi
  fi

  info "Extracting ONNX runtime (${label})…"
  tar -xzf "$archive_path" -C "$RUNTIME_DIR"

  if [[ ! -f "$lib_path" ]]; then
    die "Runtime (${label}) archive extracted but library missing: ${lib_path}"
  fi

  rm -f "$archive_path"
  ok "ONNX runtime (${label}) ready"
}

provision_runtime() {
  local archive_name="${RUNTIME_ARCHIVE[$PLATFORM]}"
  local url="${RUNTIME_URL[$PLATFORM]}"
  local sha256="${RUNTIME_SHA256[$PLATFORM]}"
  local lib_rel="${RUNTIME_LIB[$PLATFORM]}"

  if [[ -z "$archive_name" ]]; then
    die "No ONNX runtime spec for platform ${PLATFORM}"
  fi

  provision_one_runtime "cpu" "$archive_name" "$url" "$sha256" "$lib_rel"

  # GPU variant — only available for Linux amd64
  local gpu_archive=""
  if [[ -v RUNTIME_GPU_ARCHIVE[$PLATFORM] ]]; then
    gpu_archive="${RUNTIME_GPU_ARCHIVE[$PLATFORM]}"
  fi
  if [[ -n "$gpu_archive" ]]; then
    provision_one_runtime "cuda" "$gpu_archive" \
      "${RUNTIME_GPU_URL[$PLATFORM]}" "${RUNTIME_GPU_SHA256[$PLATFORM]}" \
      "${RUNTIME_GPU_LIB[$PLATFORM]}"
  fi
}

# ── Main ──────────────────────────────────────────────────────────────

main() {
  info "Target directory: ${TARGET_DIR}"
  mkdir -p "$MODELS_DIR" "$RUNTIME_DIR"

  # ── Nomic Embed Text v1.5 (primary embedder) ──
  # Quantization level: LIBRAVDB_NOMIC_QUANT env var, one of:
  #   q8      — 8-bit int (recommended, ~137MB, fastest on CPU)
  #   fp32    — full precision (~547MB, reproducibility)
  NOMIC_QUANT="${LIBRAVDB_NOMIC_QUANT:-q8}"
  case "$NOMIC_QUANT" in
    q8)      NOMIC_MODEL="model_quantized.onnx"; NOMIC_SHA="" ;;
    fp32)    NOMIC_MODEL="model.onnx"
             NOMIC_SHA="147d5aa88c2101237358e17796cf3a227cead1ec304ec34b465bb08e9d952965" ;;
    *)       die "Unknown LIBRAVDB_NOMIC_QUANT=${NOMIC_QUANT} (use: q8, fp32)" ;;
  esac

  info "Provisioning nomic-embed-text-v1.5 (${NOMIC_QUANT}: ${NOMIC_MODEL})…"
  NOMIC_MODEL_DIR="${MODELS_DIR}/nomic-embed-text-v1.5"
  mkdir -p "$NOMIC_MODEL_DIR"

  ensure_asset \
    "nomic-embed-text-v1.5 ${NOMIC_QUANT} model" \
    "https://huggingface.co/nomic-ai/nomic-embed-text-v1.5/resolve/main/onnx/${NOMIC_MODEL}" \
    "${NOMIC_MODEL_DIR}/${NOMIC_MODEL}" \
    "$NOMIC_SHA"

  ensure_asset \
    "nomic-embed-text-v1.5 tokenizer" \
    "https://huggingface.co/nomic-ai/nomic-embed-text-v1.5/resolve/main/tokenizer.json" \
    "${NOMIC_MODEL_DIR}/tokenizer.json" \
    "d241a60d5e8f04cc1b2b3e9ef7a4921b27bf526d9f6050ab90f9267a1f9e5c66"

  write_nomic_manifest "$NOMIC_MODEL"

  # ── BGE-Small-EN-v1.5 (fallback embedder) ──
  info "Provisioning bge-small-en-v1.5…"
  ensure_asset \
    "bge-small-en-v1.5 model" \
    "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/onnx/model.onnx" \
    "${MODELS_DIR}/bge-small-en-v1.5/model.onnx" \
    "828e1496d7fabb79cfa4dcd84fa38625c0d3d21da474a00f08db0f559940cf35"

  ensure_asset \
    "bge-small-en-v1.5 tokenizer" \
    "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/tokenizer.json" \
    "${MODELS_DIR}/bge-small-en-v1.5/tokenizer.json" \
    "d241a60d5e8f04cc1b2b3e9ef7a4921b27bf526d9f6050ab90f9267a1f9e5c66"

  write_bge_manifest

  # ── ONNX Runtime ──
  provision_runtime

  echo ""
  ok "Provisioning complete.  Asset directory: ${TARGET_DIR}"
  ok "Models and ONNX runtime are ready in: ${TARGET_DIR}"
}

main "$@"
